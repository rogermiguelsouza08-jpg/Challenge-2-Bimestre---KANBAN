package com.miltinho.manager;

import com.miltinho.manager.service.PedidoService;
import com.miltinho.manager.service.ProdutoService;
import com.miltinho.manager.service.UsuarioService;
import com.miltinho.manager.ui.LoginFrame;
import com.miltinho.manager.ui.MenuFrame;
import com.miltinho.manager.ui.UIEstilo;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

import javax.swing.SwingUtilities;

/**
 * Classe principal do Miltinho Manager.
 *
 * Inicializa o contexto Spring (JPA, H2, servicos) e abre a tela de Login.
 * A interface grafica e construida com Swing.
 *
 * Como executar:
 *   mvn spring-boot:run
 *   ou
 *   java -jar miltinho-manager.jar
 *
 * Acesso padrao: login=admin, senha=admin123
 * Console H2: http://localhost:8080/h2-console
 */
@SpringBootApplication
public class MiltinhoApp {

    // Contexto Spring compartilhado com as telas Swing
    private static ConfigurableApplicationContext ctx;

    public static void main(String[] args) {
        // Garante modo grafico antes de qualquer coisa (necessario no NetBeans)
        System.setProperty("java.awt.headless", "false");

        // Inicia o Spring como aplicacao Web (para o console H2),
        // mas sem abrir um browser automaticamente.
        ctx = new SpringApplicationBuilder(MiltinhoApp.class)
                .headless(false)              // permite UI Swing
                .web(WebApplicationType.SERVLET)
                .run(args);

        UIEstilo.aplicarLaf();

        SwingUtilities.invokeLater(() -> {
            UsuarioService usuarioService = ctx.getBean(UsuarioService.class);
            LoginFrame login = new LoginFrame(usuarioService);
            login.setVisible(true);
        });
    }

    /** Chamado pelo LoginFrame apos autenticacao bem-sucedida. */
    public static void abrirMenu() {
        MenuFrame menu = new MenuFrame();
        menu.setVisible(true);
    }

    // ---- Getters de servicos (acessados pelas telas Swing) ----

    public static ProdutoService getProdutoService() {
        return ctx.getBean(ProdutoService.class);
    }

    public static PedidoService getPedidoService() {
        return ctx.getBean(PedidoService.class);
    }

    public static UsuarioService getUsuarioService() {
        return ctx.getBean(UsuarioService.class);
    }
}
