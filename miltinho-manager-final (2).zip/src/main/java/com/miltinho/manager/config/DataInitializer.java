package com.miltinho.manager.config;

import com.miltinho.manager.model.Pedido;
import com.miltinho.manager.model.Produto;
import com.miltinho.manager.model.Usuario;
import com.miltinho.manager.service.PedidoService;
import com.miltinho.manager.service.ProdutoService;
import com.miltinho.manager.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * Popula o banco H2 com dados de exemplo na primeira execucao.
 * Nas execucoes seguintes, como ddl-auto=update, os dados ja existem.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioService usuarioService;
    private final ProdutoService produtoService;
    private final PedidoService pedidoService;

    @Autowired
    public DataInitializer(UsuarioService usuarioService,
                           ProdutoService produtoService,
                           PedidoService pedidoService) {
        this.usuarioService = usuarioService;
        this.produtoService = produtoService;
        this.pedidoService = pedidoService;
    }

    @Override
    public void run(String... args) {
        // Somente popula se o banco estiver vazio
        if (usuarioService.existeAlgumUsuario()) {
            System.out.println("[DataInitializer] Banco ja populado. Nenhuma acao necessaria.");
            return;
        }

        System.out.println("[DataInitializer] Populando banco de dados com dados iniciais...");

        // ---- Usuarios ----
        usuarioService.salvar(new Usuario("Administrador", "admin", "admin123"));
        usuarioService.salvar(new Usuario("Miltinho", "miltinho", "miltinho"));

        // ---- Produtos ----
        Produto marmitex = produtoService.salvar(new Produto("Marmitex Tradicional", 15.00, 50));
        Produto marmitexG  = produtoService.salvar(new Produto("Marmitex Grande", 20.00, 30));
        Produto cerveja    = produtoService.salvar(new Produto("Cerveja 600ml", 8.50, 120));
        Produto refri      = produtoService.salvar(new Produto("Refrigerante Lata", 5.00, 80));
        Produto porcao     = produtoService.salvar(new Produto("Porcao de Batata Frita", 22.00, 10));
        Produto agua       = produtoService.salvar(new Produto("Agua Mineral 500ml", 3.00, 200));

        // ---- Pedidos de exemplo ----
        LocalDate hoje = LocalDate.now();

        Pedido p1 = new Pedido("Joao Silva", marmitex, 2, hoje);
        p1.setStatus(Pedido.Status.ENTREGUE);
        pedidoService.salvar(p1);

        Pedido p2 = new Pedido("Maria Oliveira", marmitexG, 1, hoje);
        p2.setStatus(Pedido.Status.EM_PREPARO);
        pedidoService.salvar(p2);

        Pedido p3 = new Pedido("Carlos Santos", cerveja, 4, hoje);
        p3.setStatus(Pedido.Status.AGENDADO);
        pedidoService.salvar(p3);

        Pedido p4 = new Pedido("Ana Lima", marmitex, 3, hoje.minusDays(1));
        p4.setStatus(Pedido.Status.ENTREGUE);
        pedidoService.salvar(p4);

        Pedido p5 = new Pedido("Pedro Souza", porcao, 1, hoje);
        p5.setStatus(Pedido.Status.AGENDADO);
        pedidoService.salvar(p5);

        System.out.println("[DataInitializer] Dados iniciais inseridos com sucesso.");
        System.out.println("  Login padrao: admin / admin123");
    }
}
