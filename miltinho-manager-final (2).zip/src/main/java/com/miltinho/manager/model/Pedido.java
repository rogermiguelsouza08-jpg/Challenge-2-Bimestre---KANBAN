package com.miltinho.manager.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDate;

/**
 * Representa um pedido de cliente no Bar e Restaurante Miltinho.
 */
@Entity
@Table(name = "pedido")
public class Pedido {

    public enum Status {
        AGENDADO("Agendado"),
        EM_PREPARO("Em preparo"),
        ENTREGUE("Entregue"),
        CANCELADO("Cancelado");

        private final String descricao;

        Status(String descricao) {
            this.descricao = descricao;
        }

        public String getDescricao() {
            return descricao;
        }

        @Override
        public String toString() {
            return descricao;
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nome_cliente", nullable = false, length = 100)
    private String nomeCliente;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "produto_id", nullable = false)
    private Produto produto;

    @Column(nullable = false)
    private Integer quantidade;

    @Column(name = "data_pedido", nullable = false)
    private LocalDate dataPedido;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Status status;

    public Pedido() {
        this.dataPedido = LocalDate.now();
        this.status = Status.AGENDADO;
    }

    public Pedido(String nomeCliente, Produto produto, Integer quantidade, LocalDate dataPedido) {
        this.nomeCliente = nomeCliente;
        this.produto = produto;
        this.quantidade = quantidade;
        this.dataPedido = dataPedido;
        this.status = Status.AGENDADO;
    }

    /** Valor total estimado do pedido */
    public double getTotal() {
        if (produto == null || quantidade == null) return 0.0;
        return produto.getPreco() * quantidade;
    }

    // ----------------- Getters e Setters -----------------

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNomeCliente() { return nomeCliente; }
    public void setNomeCliente(String nomeCliente) { this.nomeCliente = nomeCliente; }

    public Produto getProduto() { return produto; }
    public void setProduto(Produto produto) { this.produto = produto; }

    public Integer getQuantidade() { return quantidade; }
    public void setQuantidade(Integer quantidade) { this.quantidade = quantidade; }

    public LocalDate getDataPedido() { return dataPedido; }
    public void setDataPedido(LocalDate dataPedido) { this.dataPedido = dataPedido; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
}
