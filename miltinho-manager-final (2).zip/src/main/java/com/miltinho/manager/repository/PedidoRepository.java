package com.miltinho.manager.repository;

import com.miltinho.manager.model.Pedido;
import com.miltinho.manager.model.Pedido.Status;
import com.miltinho.manager.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Repositorio JPA para a entidade Pedido.
 */
@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    /** Busca pedidos de um cliente pelo nome (case-insensitive). */
    List<Pedido> findByNomeClienteContainingIgnoreCase(String nomeCliente);

    /** Busca pedidos por status. */
    List<Pedido> findByStatus(Status status);

    /** Busca pedidos por data. */
    List<Pedido> findByDataPedido(LocalDate data);

    /** Total de pedidos em um mes/ano especifico. */
    @Query("SELECT COUNT(p) FROM Pedido p WHERE YEAR(p.dataPedido) = :ano AND MONTH(p.dataPedido) = :mes")
    long countByMesAno(int ano, int mes);

    /** Produto mais pedido (por quantidade total de itens). */
    @Query("SELECT p.produto, SUM(p.quantidade) AS total FROM Pedido p GROUP BY p.produto ORDER BY total DESC")
    List<Object[]> findProdutoMaisPedido();

    /** Soma do valor total de pedidos entregues no mes/ano. */
    @Query("SELECT COALESCE(SUM(p.quantidade * pr.preco), 0) " +
           "FROM Pedido p JOIN p.produto pr " +
           "WHERE p.status = 'ENTREGUE' " +
           "AND YEAR(p.dataPedido) = :ano AND MONTH(p.dataPedido) = :mes")
    double faturamentoMes(int ano, int mes);
}
