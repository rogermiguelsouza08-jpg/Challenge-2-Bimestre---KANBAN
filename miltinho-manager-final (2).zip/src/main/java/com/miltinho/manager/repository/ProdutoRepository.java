package com.miltinho.manager.repository;

import com.miltinho.manager.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repositorio JPA para a entidade Produto.
 * O Spring Data gera automaticamente as implementacoes dos metodos CRUD.
 */
@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {

    /** Busca produtos cujo nome contenha o texto informado (case-insensitive). */
    List<Produto> findByNomeContainingIgnoreCase(String nome);

    /** Retorna produtos com estoque abaixo do limite informado. */
    List<Produto> findByQuantidadeEstoqueLessThan(Integer limite);
}
