package com.miltinho.manager.repository;

import com.miltinho.manager.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repositorio JPA para a entidade Usuario.
 */
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    /** Busca usuario pelo login. */
    Optional<Usuario> findByLogin(String login);

    /** Verifica credenciais de login e senha. */
    Optional<Usuario> findByLoginAndSenha(String login, String senha);
}
