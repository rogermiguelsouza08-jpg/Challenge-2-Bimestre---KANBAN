package com.miltinho.manager.service;

import com.miltinho.manager.model.Pedido;
import com.miltinho.manager.model.Pedido.Status;
import com.miltinho.manager.model.Produto;
import com.miltinho.manager.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Servico responsavel pelas regras de negocio relacionadas a Pedido.
 */
@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;

    @Autowired
    public PedidoService(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    /** Salva (cria ou atualiza) um pedido, validando os campos obrigatorios. */
    public Pedido salvar(Pedido pedido) {
        if (pedido.getNomeCliente() == null || pedido.getNomeCliente().isBlank()) {
            throw new IllegalArgumentException("O nome do cliente nao pode estar vazio.");
        }
        if (pedido.getProduto() == null) {
            throw new IllegalArgumentException("Selecione um produto para o pedido.");
        }
        if (pedido.getQuantidade() == null || pedido.getQuantidade() <= 0) {
            throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
        }
        if (pedido.getDataPedido() == null) {
            pedido.setDataPedido(LocalDate.now());
        }
        if (pedido.getStatus() == null) {
            pedido.setStatus(Status.AGENDADO);
        }
        return pedidoRepository.save(pedido);
    }

    /** Lista todos os pedidos. */
    public List<Pedido> listarTodos() {
        return pedidoRepository.findAll();
    }

    /** Busca pedido por ID. */
    public Optional<Pedido> buscarPorId(Long id) {
        return pedidoRepository.findById(id);
    }

    /** Busca pedidos pelo nome do cliente. */
    public List<Pedido> buscarPorCliente(String nomeCliente) {
        return pedidoRepository.findByNomeClienteContainingIgnoreCase(nomeCliente);
    }

    /** Busca pedidos por status. */
    public List<Pedido> buscarPorStatus(Status status) {
        return pedidoRepository.findByStatus(status);
    }

    /** Atualiza o status de um pedido. */
    public Pedido atualizarStatus(Long id, Status novoStatus) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Pedido nao encontrado: " + id));
        pedido.setStatus(novoStatus);
        return pedidoRepository.save(pedido);
    }

    /** Exclui um pedido por ID. */
    public void excluir(Long id) {
        pedidoRepository.deleteById(id);
    }

    // ---- Metodos para Relatorios ----

    public long totalPedidosMes(int ano, int mes) {
        return pedidoRepository.countByMesAno(ano, mes);
    }

    public double faturamentoMes(int ano, int mes) {
        return pedidoRepository.faturamentoMes(ano, mes);
    }

    /**
     * Retorna o produto mais pedido (por quantidade total de itens)
     * ou null se nao houver pedidos.
     */
    public Produto produtoMaisPedido() {
        List<Object[]> resultado = pedidoRepository.findProdutoMaisPedido();
        if (resultado == null || resultado.isEmpty()) return null;
        return (Produto) resultado.get(0)[0];
    }
}
