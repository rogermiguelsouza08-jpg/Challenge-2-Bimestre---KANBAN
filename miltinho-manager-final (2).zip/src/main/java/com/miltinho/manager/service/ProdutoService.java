package com.miltinho.manager.service;

import com.miltinho.manager.model.Produto;
import com.miltinho.manager.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Servico responsavel pelas regras de negocio relacionadas a Produto.
 */
@Service
public class ProdutoService {

    private final ProdutoRepository produtoRepository;

    @Autowired
    public ProdutoService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    /** Salva (cria ou atualiza) um produto. */
    public Produto salvar(Produto produto) {
        if (produto.getNome() == null || produto.getNome().isBlank()) {
            throw new IllegalArgumentException("O nome do produto nao pode estar vazio.");
        }
        if (produto.getPreco() == null || produto.getPreco() < 0) {
            throw new IllegalArgumentException("O preco deve ser maior ou igual a zero.");
        }
        if (produto.getQuantidadeEstoque() == null || produto.getQuantidadeEstoque() < 0) {
            throw new IllegalArgumentException("A quantidade em estoque nao pode ser negativa.");
        }
        return produtoRepository.save(produto);
    }

    /** Lista todos os produtos cadastrados. */
    public List<Produto> listarTodos() {
        return produtoRepository.findAll();
    }

    /** Busca produto por ID. */
    public Optional<Produto> buscarPorId(Long id) {
        return produtoRepository.findById(id);
    }

    /** Busca produtos pelo nome. */
    public List<Produto> buscarPorNome(String nome) {
        return produtoRepository.findByNomeContainingIgnoreCase(nome);
    }

    /** Exclui produto por ID. */
    public void excluir(Long id) {
        produtoRepository.deleteById(id);
    }

    /** Retorna produtos com estoque abaixo de 10 unidades. */
    public List<Produto> produtosComEstoqueBaixo() {
        return produtoRepository.findByQuantidadeEstoqueLessThan(10);
    }
}
