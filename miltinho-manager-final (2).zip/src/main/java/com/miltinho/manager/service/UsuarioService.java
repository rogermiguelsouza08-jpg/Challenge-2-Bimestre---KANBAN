package com.miltinho.manager.service;

import com.miltinho.manager.model.Usuario;
import com.miltinho.manager.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Servico responsavel pela autenticacao e gestao de usuarios.
 */
@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    @Autowired
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Autentica um usuario.
     * @return o Usuario encontrado, ou Optional.empty() se as credenciais forem invalidas.
     */
    public Optional<Usuario> autenticar(String login, String senha) {
        return usuarioRepository.findByLoginAndSenha(login, senha);
    }

    /** Salva um usuario (cria ou atualiza). */
    public Usuario salvar(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    /** Verifica se ja existe algum usuario cadastrado (para popular o banco na 1a execucao). */
    public boolean existeAlgumUsuario() {
        return usuarioRepository.count() > 0;
    }
}
