package com.miltinho.manager.ui;

import com.miltinho.manager.model.Pedido;
import com.miltinho.manager.model.Pedido.Status;
import com.miltinho.manager.service.PedidoService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Tela de Consulta e Gestão de Pedidos.
 * Permite buscar, atualizar status e excluir pedidos.
 */
public class ConsultaPedidoFrame extends JFrame {

    private final PedidoService pedidoService;
    private final JFrame pai;

    private JTextField campoBusca;
    private JComboBox<String> comboFiltro;
    private DefaultTableModel modeloTabela;
    private JTable tabela;
    private JComboBox<Status> comboStatus;

    public ConsultaPedidoFrame(PedidoService pedidoService, JFrame pai) {
        this.pedidoService = pedidoService;
        this.pai = pai;
        construirUI();
        carregarTabela(pedidoService.listarTodos());
    }

    private void construirUI() {
        setTitle("Miltinho Manager — Consulta e Gestão de Pedidos");
        setSize(760, 520);
        setLocationRelativeTo(pai);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = UIEstilo.painel();
        root.setLayout(new BorderLayout(0, 10));
        root.setBorder(new EmptyBorder(16, 20, 16, 20));

        root.add(UIEstilo.titulo("Consulta e Gestão de Pedidos"), BorderLayout.NORTH);

        // ---- Barra de busca ----
        JPanel barraBusca = UIEstilo.painel();
        barraBusca.setLayout(new FlowLayout(FlowLayout.LEFT, 8, 4));

        campoBusca = UIEstilo.campo();
        campoBusca.setPreferredSize(new Dimension(220, 30));

        String[] filtros = {"Todos", "Por cliente", "Por status"};
        comboFiltro = new JComboBox<>(filtros);
        comboFiltro.setFont(UIEstilo.F_BODY);

        comboStatus = new JComboBox<>(Status.values());
        comboStatus.setFont(UIEstilo.F_BODY);
        comboStatus.setVisible(false);

        JButton btnBuscar   = UIEstilo.botaoPrimario("Buscar");
        JButton btnAtualizar = UIEstilo.botaoPrimario("Atualizar Status");
        JButton btnExcluir  = UIEstilo.botaoPerigo("Excluir");
        JButton btnVoltar   = UIEstilo.botaoSecundario("← Voltar");

        for (JButton b : new JButton[]{btnBuscar, btnAtualizar, btnExcluir, btnVoltar}) {
            b.setPreferredSize(new Dimension(140, 30));
        }

        barraBusca.add(new JLabel("Buscar:"));
        barraBusca.add(campoBusca);
        barraBusca.add(comboFiltro);
        barraBusca.add(comboStatus);
        barraBusca.add(btnBuscar);
        barraBusca.add(new JSeparator(SwingConstants.VERTICAL));
        barraBusca.add(btnAtualizar);
        barraBusca.add(btnExcluir);
        barraBusca.add(btnVoltar);

        // ---- Tabela ----
        String[] colunas = {"ID", "Cliente", "Produto", "Qtd", "Data", "Status", "Total (R$)"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modeloTabela);
        tabela.setFont(UIEstilo.F_BODY);
        tabela.setRowHeight(24);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getTableHeader().setFont(UIEstilo.F_BODY);
        tabela.getColumnModel().getColumn(0).setMaxWidth(45);
        tabela.getColumnModel().getColumn(3).setMaxWidth(45);
        tabela.getColumnModel().getColumn(5).setPreferredWidth(100);

        JScrollPane scroll = new JScrollPane(tabela);

        root.add(barraBusca, BorderLayout.CENTER);
        root.add(scroll, BorderLayout.SOUTH);
        scroll.setPreferredSize(new Dimension(0, 350));

        setContentPane(root);

        // ---- Eventos ----
        comboFiltro.addActionListener(e -> {
            boolean porStatus = "Por status".equals(comboFiltro.getSelectedItem());
            comboStatus.setVisible(porStatus);
            campoBusca.setEnabled(!"Por status".equals(comboFiltro.getSelectedItem()));
        });

        btnBuscar.addActionListener(e -> buscar());
        btnAtualizar.addActionListener(e -> atualizarStatus());
        btnExcluir.addActionListener(e -> excluir());
        btnVoltar.addActionListener(e -> dispose());
    }

    private void carregarTabela(List<Pedido> pedidos) {
        modeloTabela.setRowCount(0);
        for (Pedido p : pedidos) {
            modeloTabela.addRow(new Object[]{
                p.getId(),
                p.getNomeCliente(),
                p.getProduto() != null ? p.getProduto().getNome() : "-",
                p.getQuantidade(),
                p.getDataPedido(),
                p.getStatus().getDescricao(),
                String.format("%.2f", p.getTotal())
            });
        }
    }

    private void buscar() {
        String filtro = (String) comboFiltro.getSelectedItem();
        List<Pedido> resultado;
        switch (filtro) {
            case "Por cliente" -> resultado = pedidoService.buscarPorCliente(campoBusca.getText().trim());
            case "Por status"  -> resultado = pedidoService.buscarPorStatus((Status) comboStatus.getSelectedItem());
            default            -> resultado = pedidoService.listarTodos();
        }
        carregarTabela(resultado);
    }

    private Long getIdSelecionado() {
        int linha = tabela.getSelectedRow();
        if (linha < 0) return null;
        return (Long) modeloTabela.getValueAt(linha, 0);
    }

    private void atualizarStatus() {
        Long id = getIdSelecionado();
        if (id == null) { JOptionPane.showMessageDialog(this, "Selecione um pedido."); return; }

        Status[] opcoes = Status.values();
        Status escolhido = (Status) JOptionPane.showInputDialog(
                this, "Novo status:", "Atualizar Status",
                JOptionPane.PLAIN_MESSAGE, null, opcoes, opcoes[0]);
        if (escolhido == null) return;

        pedidoService.atualizarStatus(id, escolhido);
        JOptionPane.showMessageDialog(this, "Status atualizado para: " + escolhido.getDescricao());
        buscar();
    }

    private void excluir() {
        Long id = getIdSelecionado();
        if (id == null) { JOptionPane.showMessageDialog(this, "Selecione um pedido."); return; }
        int ok = JOptionPane.showConfirmDialog(this, "Excluir pedido #" + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            pedidoService.excluir(id);
            buscar();
        }
    }
}
