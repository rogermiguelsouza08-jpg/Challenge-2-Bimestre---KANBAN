package com.miltinho.manager.ui;

import com.miltinho.manager.MiltinhoApp;
import com.miltinho.manager.model.Usuario;
import com.miltinho.manager.service.UsuarioService;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Optional;

/**
 * Tela de Login do Miltinho Manager.
 */
public class LoginFrame extends JFrame {

    private final UsuarioService usuarioService;
    private JTextField campoLogin;
    private JPasswordField campoSenha;

    public LoginFrame(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
        construirUI();
    }

    private void construirUI() {
        setTitle("Miltinho Manager — Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 380);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = UIEstilo.painel();
        root.setLayout(new BorderLayout());
        root.setBorder(new EmptyBorder(30, 40, 30, 40));

        // ---- Cabecalho ----
        JPanel header = UIEstilo.painel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));

        JLabel lblApp = new JLabel("Miltinho Manager", SwingConstants.CENTER);
        lblApp.setFont(new Font("Arial", Font.BOLD, 22));
        lblApp.setForeground(UIEstilo.NAVY);
        lblApp.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblSub = new JLabel("Bar e Restaurante Miltinho", SwingConstants.CENTER);
        lblSub.setFont(UIEstilo.F_SMALL);
        lblSub.setForeground(UIEstilo.TEXT_MUTE);
        lblSub.setAlignmentX(CENTER_ALIGNMENT);

        header.add(lblApp);
        header.add(Box.createVerticalStrut(4));
        header.add(lblSub);
        header.add(Box.createVerticalStrut(24));

        // ---- Formulario ----
        JPanel form = UIEstilo.painel();
        form.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(6, 0, 6, 0);
        c.weightx = 1.0;

        campoLogin = UIEstilo.campo();
        campoSenha = new JPasswordField();
        campoSenha.setFont(UIEstilo.F_BODY);
        campoSenha.setBorder(UIEstilo.bordaCampo());

        c.gridx = 0; c.gridy = 0;
        form.add(UIEstilo.rotulo("Usuário"), c);
        c.gridy = 1;
        form.add(campoLogin, c);
        c.gridy = 2;
        form.add(Box.createVerticalStrut(6), c);
        c.gridy = 3;
        form.add(UIEstilo.rotulo("Senha"), c);
        c.gridy = 4;
        form.add(campoSenha, c);
        c.gridy = 5;
        form.add(Box.createVerticalStrut(10), c);

        JButton btnEntrar = UIEstilo.botaoPrimario("Entrar");
        btnEntrar.setPreferredSize(new Dimension(200, 36));
        c.gridy = 6;
        form.add(btnEntrar, c);

        JLabel dica = new JLabel("Padrão: admin / admin123", SwingConstants.CENTER);
        dica.setFont(UIEstilo.F_SMALL);
        dica.setForeground(UIEstilo.TEXT_MUTE);
        c.gridy = 7;
        c.insets = new Insets(10, 0, 0, 0);
        form.add(dica, c);

        // ---- Acao do botao Entrar ----
        btnEntrar.addActionListener(e -> realizarLogin());
        campoSenha.addActionListener(e -> realizarLogin());

        root.add(header, BorderLayout.NORTH);
        root.add(form, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void realizarLogin() {
        String login = campoLogin.getText().trim();
        String senha = new String(campoSenha.getPassword()).trim();

        if (login.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Preencha o login e a senha.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Optional<Usuario> usuario = usuarioService.autenticar(login, senha);
        if (usuario.isPresent()) {
            SwingUtilities.invokeLater(() -> {
                dispose();
                // MenuFrame e injetado via Spring no MiltinhoApp — aqui abrimos diretamente
                MiltinhoApp.abrirMenu();
            });
        } else {
            JOptionPane.showMessageDialog(this,
                    "Login ou senha incorretos.", "Erro de autenticação", JOptionPane.ERROR_MESSAGE);
            campoSenha.setText("");
            campoSenha.requestFocus();
        }
    }
}
