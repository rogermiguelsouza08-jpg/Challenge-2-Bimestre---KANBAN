package com.miltinho.manager.ui;

import com.miltinho.manager.MiltinhoApp;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

/**
 * Menu principal do Miltinho Manager.
 * Centraliza o acesso a todas as telas do sistema.
 */
public class MenuFrame extends JFrame {

    public MenuFrame() {
        construirUI();
    }

    private void construirUI() {
        setTitle("Miltinho Manager — Menu Principal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 440);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = UIEstilo.painel();
        root.setLayout(new BorderLayout(0, 0));
        root.setBorder(new EmptyBorder(28, 40, 28, 40));

        // ---- Cabecalho ----
        JLabel lblTitulo = new JLabel("Menu Principal", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setForeground(UIEstilo.NAVY);
        lblTitulo.setBorder(new EmptyBorder(0, 0, 20, 0));

        // ---- Grade de botoes ----
        JPanel grade = UIEstilo.painel();
        grade.setLayout(new GridLayout(3, 2, 14, 14));

        Dimension dimBotao = new Dimension(190, 54);

        JButton btnProdutos   = botaoMenu("📦  Produtos");
        JButton btnPedidos    = botaoMenu("🧾  Pedidos");
        JButton btnConsulta   = botaoMenu("🔍  Consultar Pedidos");
        JButton btnRelatorio  = botaoMenu("📊  Relatórios");
        JButton btnSobre      = botaoMenu("ℹ️  Sobre");
        JButton btnSair       = UIEstilo.botaoSecundario("🚪  Sair");
        btnSair.setFont(UIEstilo.F_BTN);

        for (JButton b : new JButton[]{btnProdutos, btnPedidos, btnConsulta, btnRelatorio, btnSobre, btnSair}) {
            b.setPreferredSize(dimBotao);
            grade.add(b);
        }

        // ---- Acoes ----
        btnProdutos.addActionListener(e ->
                new ProdutoFrame(MiltinhoApp.getProdutoService(), this).setVisible(true));

        btnPedidos.addActionListener(e ->
                new PedidoFrame(MiltinhoApp.getPedidoService(), MiltinhoApp.getProdutoService(), this).setVisible(true));

        btnConsulta.addActionListener(e ->
                new ConsultaPedidoFrame(MiltinhoApp.getPedidoService(), this).setVisible(true));

        btnRelatorio.addActionListener(e ->
                new RelatorioFrame(MiltinhoApp.getPedidoService(), MiltinhoApp.getProdutoService(), this).setVisible(true));

        btnSobre.addActionListener(e ->
                new SobreFrame(this).setVisible(true));

        btnSair.addActionListener(e -> System.exit(0));

        root.add(lblTitulo, BorderLayout.NORTH);
        root.add(grade, BorderLayout.CENTER);
        setContentPane(root);
    }

    private JButton botaoMenu(String texto) {
        JButton b = UIEstilo.botaoPrimario(texto);
        b.setFont(UIEstilo.F_BTN);
        return b;
    }
}
