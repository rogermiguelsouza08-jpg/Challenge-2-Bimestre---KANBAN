package com.miltinho.manager.ui;

import com.miltinho.manager.model.Pedido;
import com.miltinho.manager.model.Produto;
import com.miltinho.manager.service.PedidoService;
import com.miltinho.manager.service.ProdutoService;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * Tela de Cadastro de Pedidos.
 */
public class PedidoFrame extends JFrame {

    private final PedidoService pedidoService;
    private final ProdutoService produtoService;
    private final JFrame pai;

    private JTextField campoCliente;
    private JComboBox<Produto> comboProduto;
    private JTextField campoQuantidade;
    private JTextField campoData;
    private JLabel lblResumo;

    public PedidoFrame(PedidoService pedidoService, ProdutoService produtoService, JFrame pai) {
        this.pedidoService = pedidoService;
        this.produtoService = produtoService;
        this.pai = pai;
        construirUI();
    }

    private void construirUI() {
        setTitle("Miltinho Manager — Cadastro de Pedidos");
        setSize(620, 420);
        setLocationRelativeTo(pai);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = UIEstilo.painel();
        root.setLayout(new BorderLayout(0, 12));
        root.setBorder(new EmptyBorder(18, 22, 18, 22));
        root.add(UIEstilo.titulo("Cadastro de Pedidos"), BorderLayout.NORTH);

        // ---- Formulario ----
        JPanel form = UIEstilo.painel();
        form.setLayout(new GridLayout(2, 4, 12, 8));

        campoCliente    = UIEstilo.campo();
        comboProduto    = new JComboBox<>();
        comboProduto.setFont(UIEstilo.F_BODY);
        campoQuantidade = UIEstilo.campo();
        campoData       = UIEstilo.campo();
        campoData.setText(LocalDate.now().toString());

        form.add(UIEstilo.rotulo("Nome do cliente"));
        form.add(UIEstilo.rotulo("Produto"));
        form.add(UIEstilo.rotulo("Quantidade"));
        form.add(UIEstilo.rotulo("Data (AAAA-MM-DD)"));
        form.add(campoCliente);
        form.add(comboProduto);
        form.add(campoQuantidade);
        form.add(campoData);

        // ---- Botoes ----
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        painelBotoes.setBackground(UIEstilo.BG);

        JButton btnConfirmar = UIEstilo.botaoPrimario("Confirmar Pedido");
        JButton btnLimpar    = UIEstilo.botaoSecundario("Limpar");
        JButton btnVoltar    = UIEstilo.botaoSecundario("← Voltar");

        for (JButton b : new JButton[]{btnConfirmar, btnLimpar, btnVoltar}) {
            b.setPreferredSize(new Dimension(150, 34));
            painelBotoes.add(b);
        }

        // ---- Resumo ----
        lblResumo = new JLabel("Preencha os campos e clique em Confirmar.");
        lblResumo.setFont(UIEstilo.F_SMALL);
        lblResumo.setForeground(UIEstilo.TEXT_MUTE);

        JPanel cardResumo = UIEstilo.painel();
        cardResumo.setLayout(new BorderLayout());
        cardResumo.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(UIEstilo.LINE),
                "Resumo do pedido",
                TitledBorder.LEFT, TitledBorder.TOP,
                UIEstilo.F_BODY, UIEstilo.ACCENT));
        cardResumo.add(lblResumo, BorderLayout.CENTER);

        JPanel centro = UIEstilo.painel();
        centro.setLayout(new BorderLayout(0, 10));
        centro.add(form, BorderLayout.NORTH);
        centro.add(painelBotoes, BorderLayout.CENTER);
        centro.add(cardResumo, BorderLayout.SOUTH);

        root.add(centro, BorderLayout.CENTER);
        setContentPane(root);

        carregarProdutos();

        comboProduto.addActionListener(e -> atualizarResumo());
        campoQuantidade.addKeyListener(new KeyAdapter() {
            @Override public void keyReleased(KeyEvent e) { atualizarResumo(); }
        });
        btnConfirmar.addActionListener(e -> confirmarPedido());
        btnLimpar.addActionListener(e -> limpar());
        btnVoltar.addActionListener(e -> dispose());
    }

    private void carregarProdutos() {
        List<Produto> produtos = produtoService.listarTodos();
        DefaultComboBoxModel<Produto> model = new DefaultComboBoxModel<>();
        for (Produto p : produtos) model.addElement(p);
        comboProduto.setModel(model);
    }

    private void atualizarResumo() {
        Produto p = (Produto) comboProduto.getSelectedItem();
        if (p == null) return;
        try {
            int qtd = Integer.parseInt(campoQuantidade.getText().trim());
            double total = p.getPreco() * qtd;
            lblResumo.setText(String.format(
                "<html>Produto: <b>%s</b> &nbsp;|&nbsp; Qtd: <b>%d</b> &nbsp;|&nbsp; Unit.: R$ %.2f &nbsp;|&nbsp; <b>Total: R$ %.2f</b></html>",
                p.getNome(), qtd, p.getPreco(), total));
        } catch (NumberFormatException ex) {
            lblResumo.setText("Informe uma quantidade válida.");
        }
    }

    private void confirmarPedido() {
        try {
            String cliente  = campoCliente.getText().trim();
            Produto produto = (Produto) comboProduto.getSelectedItem();
            int qtd         = Integer.parseInt(campoQuantidade.getText().trim());
            LocalDate data  = LocalDate.parse(campoData.getText().trim());

            Pedido pedido = new Pedido(cliente, produto, qtd, data);
            pedidoService.salvar(pedido);
            JOptionPane.showMessageDialog(this, "Pedido registrado com sucesso!");
            limpar();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Quantidade deve ser um número inteiro.", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Data inválida. Use AAAA-MM-DD.", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validação", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpar() {
        campoCliente.setText("");
        campoQuantidade.setText("");
        campoData.setText(LocalDate.now().toString());
        if (comboProduto.getItemCount() > 0) comboProduto.setSelectedIndex(0);
        lblResumo.setText("Preencha os campos e clique em Confirmar.");
    }
}
