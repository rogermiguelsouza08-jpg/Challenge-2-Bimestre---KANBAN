package com.miltinho.manager.ui;

import com.miltinho.manager.model.Produto;
import com.miltinho.manager.service.ProdutoService;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;

/**
 * Tela de Cadastro de Produtos — CRUD completo.
 */
public class ProdutoFrame extends JFrame {

    private final ProdutoService produtoService;
    private final JFrame pai;

    private JTextField campoNome;
    private JTextField campoPreco;
    private JTextField campoEstoque;
    private DefaultTableModel modeloTabela;
    private JTable tabela;

    private Long idSelecionado = null;

    public ProdutoFrame(ProdutoService produtoService, JFrame pai) {
        this.produtoService = produtoService;
        this.pai = pai;
        construirUI();
        carregarTabela();
    }

    private void construirUI() {
        setTitle("Miltinho Manager — Cadastro de Produtos");
        setSize(680, 500);
        setLocationRelativeTo(pai);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = UIEstilo.painel();
        root.setLayout(new BorderLayout(0, 10));
        root.setBorder(new EmptyBorder(18, 22, 18, 22));

        // ---- Titulo ----
        root.add(UIEstilo.titulo("Cadastro de Produtos"), BorderLayout.NORTH);

        // ---- Formulario ----
        JPanel form = UIEstilo.painel();
        form.setLayout(new GridLayout(2, 3, 12, 6));

        campoNome    = UIEstilo.campo();
        campoPreco   = UIEstilo.campo();
        campoEstoque = UIEstilo.campo();

        form.add(label("Nome do produto")); form.add(label("Preço (R$)")); form.add(label("Qtd. em estoque"));
        form.add(campoNome);               form.add(campoPreco);          form.add(campoEstoque);

        // ---- Botoes ----
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        botoes.setBackground(UIEstilo.BG);

        JButton btnSalvar  = UIEstilo.botaoPrimario("Salvar");
        JButton btnExcluir = UIEstilo.botaoPerigo("Excluir");
        JButton btnLimpar  = UIEstilo.botaoSecundario("Limpar");
        JButton btnVoltar  = UIEstilo.botaoSecundario("← Voltar");

        for (JButton b : new JButton[]{btnSalvar, btnExcluir, btnLimpar, btnVoltar}) {
            b.setPreferredSize(new Dimension(110, 34));
            botoes.add(b);
        }

        JPanel topo = UIEstilo.painel();
        topo.setLayout(new BorderLayout(0, 8));
        topo.add(form, BorderLayout.CENTER);
        topo.add(botoes, BorderLayout.SOUTH);

        // ---- Tabela ----
        String[] colunas = {"ID", "Nome", "Preço (R$)", "Estoque"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modeloTabela);
        tabela.setFont(UIEstilo.F_BODY);
        tabela.setRowHeight(24);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getTableHeader().setFont(UIEstilo.F_BODY);
        tabela.getColumnModel().getColumn(0).setMaxWidth(50);
        tabela.getColumnModel().getColumn(2).setMaxWidth(110);
        tabela.getColumnModel().getColumn(3).setMaxWidth(90);

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setPreferredSize(new Dimension(0, 260));

        root.add(topo, BorderLayout.NORTH);
        root.add(Box.createVerticalStrut(8), BorderLayout.CENTER);
        root.add(scroll, BorderLayout.SOUTH);
        setContentPane(root);

        // ---- Eventos ----
        btnSalvar.addActionListener(e -> salvar());
        btnExcluir.addActionListener(e -> excluir());
        btnLimpar.addActionListener(e -> limpar());
        btnVoltar.addActionListener(e -> dispose());

        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) preencherFormulario();
        });
    }

    private void carregarTabela() {
        modeloTabela.setRowCount(0);
        List<Produto> produtos = produtoService.listarTodos();
        for (Produto p : produtos) {
            modeloTabela.addRow(new Object[]{
                p.getId(),
                p.getNome(),
                String.format("%.2f", p.getPreco()),
                p.getQuantidadeEstoque()
            });
        }
    }

    private void preencherFormulario() {
        int linha = tabela.getSelectedRow();
        if (linha < 0) return;
        idSelecionado = (Long) modeloTabela.getValueAt(linha, 0);
        campoNome.setText((String) modeloTabela.getValueAt(linha, 1));
        campoPreco.setText(((String) modeloTabela.getValueAt(linha, 2)).replace(",", "."));
        campoEstoque.setText(String.valueOf(modeloTabela.getValueAt(linha, 3)));
    }

    private void salvar() {
        try {
            String nome = campoNome.getText().trim();
            double preco = Double.parseDouble(campoPreco.getText().trim().replace(",", "."));
            int estoque  = Integer.parseInt(campoEstoque.getText().trim());

            Produto p = idSelecionado != null
                    ? produtoService.buscarPorId(idSelecionado).orElse(new Produto())
                    : new Produto();
            p.setNome(nome);
            p.setPreco(preco);
            p.setQuantidadeEstoque(estoque);
            produtoService.salvar(p);

            JOptionPane.showMessageDialog(this, "Produto salvo com sucesso!");
            limpar();
            carregarTabela();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Preço e estoque devem ser números válidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro de validação", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluir() {
        if (idSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione um produto na tabela para excluir.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Excluir produto selecionado?", "Confirmar exclusão", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            produtoService.excluir(idSelecionado);
            limpar();
            carregarTabela();
        }
    }

    private void limpar() {
        idSelecionado = null;
        campoNome.setText("");
        campoPreco.setText("");
        campoEstoque.setText("");
        tabela.clearSelection();
    }

    private JLabel label(String texto) {
        return UIEstilo.rotulo(texto);
    }
}
