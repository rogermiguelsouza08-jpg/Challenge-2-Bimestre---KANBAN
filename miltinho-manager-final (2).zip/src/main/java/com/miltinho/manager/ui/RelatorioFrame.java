package com.miltinho.manager.ui;

import com.miltinho.manager.model.Produto;
import com.miltinho.manager.service.PedidoService;
import com.miltinho.manager.service.ProdutoService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

/**
 * Tela de Relatórios — Insight Gerencial.
 * Exibe indicadores do mes atual calculados a partir dos pedidos e estoque.
 */
public class RelatorioFrame extends JFrame {

    private final PedidoService pedidoService;
    private final ProdutoService produtoService;
    private final JFrame pai;

    public RelatorioFrame(PedidoService pedidoService, ProdutoService produtoService, JFrame pai) {
        this.pedidoService  = pedidoService;
        this.produtoService = produtoService;
        this.pai = pai;
        construirUI();
    }

    private void construirUI() {
        setTitle("Miltinho Manager — Relatórios");
        setSize(600, 480);
        setLocationRelativeTo(pai);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = UIEstilo.painel();
        root.setLayout(new BorderLayout(0, 14));
        root.setBorder(new EmptyBorder(18, 22, 18, 22));

        root.add(UIEstilo.titulo("Relatórios — Insight Gerencial"), BorderLayout.NORTH);

        // ---- Grade de cards ----
        JPanel grade = UIEstilo.painel();
        grade.setLayout(new GridLayout(2, 2, 14, 14));

        LocalDate hoje = LocalDate.now();
        int ano = hoje.getYear();
        int mes = hoje.getMonthValue();

        // Card 1: produto mais pedido
        Produto maisVendido = pedidoService.produtoMaisPedido();
        grade.add(card("Produto mais pedido",
                maisVendido != null ? maisVendido.getNome() : "Sem dados ainda"));

        // Card 2: produto com menor estoque
        List<Produto> baixoEstoque = produtoService.produtosComEstoqueBaixo();
        String txtEstoque = baixoEstoque.isEmpty()
                ? "Nenhum produto abaixo de 10 un."
                : baixoEstoque.get(0).getNome() + " — " + baixoEstoque.get(0).getQuantidadeEstoque() + " un.";
        grade.add(card("Menor estoque (< 10 un.)", txtEstoque));

        // Card 3: total de pedidos no mes
        long totalPedidos = pedidoService.totalPedidosMes(ano, mes);
        grade.add(card("Total de pedidos no mês", totalPedidos + " pedidos"));

        // Card 4: faturamento estimado
        double faturamento = pedidoService.faturamentoMes(ano, mes);
        grade.add(card("Faturamento (pedidos entregues)", String.format("R$ %.2f", faturamento)));

        // ---- Alertas de estoque ----
        JPanel alertas = UIEstilo.painel();
        alertas.setLayout(new BorderLayout());
        alertas.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(UIEstilo.LINE),
                "Produtos com estoque baixo (< 10 unidades)",
                TitledBorder.LEFT, TitledBorder.TOP, UIEstilo.F_BODY, UIEstilo.ACCENT));

        JTextArea txtAlertas = new JTextArea();
        txtAlertas.setFont(UIEstilo.F_SMALL);
        txtAlertas.setEditable(false);
        txtAlertas.setBackground(UIEstilo.BG);
        if (baixoEstoque.isEmpty()) {
            txtAlertas.setText("Nenhum produto com estoque crítico.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (Produto p : baixoEstoque) {
                sb.append("• ").append(p.getNome()).append(" — ").append(p.getQuantidadeEstoque()).append(" un.\n");
            }
            txtAlertas.setText(sb.toString().trim());
        }
        alertas.add(txtAlertas, BorderLayout.CENTER);

        // ---- Botao voltar ----
        JPanel rodape = UIEstilo.painel();
        rodape.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton btnVoltar = UIEstilo.botaoSecundario("← Voltar");
        btnVoltar.setPreferredSize(new Dimension(120, 32));
        btnVoltar.addActionListener(e -> dispose());
        rodape.add(btnVoltar);

        JPanel centro = UIEstilo.painel();
        centro.setLayout(new BorderLayout(0, 10));
        centro.add(grade, BorderLayout.NORTH);
        centro.add(alertas, BorderLayout.CENTER);

        root.add(centro, BorderLayout.CENTER);
        root.add(rodape, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private JPanel card(String titulo, String valor) {
        JPanel c = new JPanel(new BorderLayout(0, 6));
        c.setBackground(UIEstilo.BG_CARD);
        c.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIEstilo.LINE),
                new EmptyBorder(12, 14, 12, 14)));

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(UIEstilo.F_SMALL);
        lblTitulo.setForeground(UIEstilo.TEXT_MUTE);

        // Faixa colorida no topo do card
        JPanel faixa = new JPanel();
        faixa.setBackground(UIEstilo.ACCENT);
        faixa.setPreferredSize(new Dimension(0, 5));

        JLabel lblValor = new JLabel("<html>" + valor + "</html>");
        lblValor.setFont(new Font("Arial", Font.BOLD, 15));
        lblValor.setForeground(UIEstilo.TEXT);

        c.add(faixa, BorderLayout.NORTH);
        c.add(lblTitulo, BorderLayout.CENTER);
        c.add(lblValor, BorderLayout.SOUTH);
        return c;
    }
}
