package com.miltinho.manager.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Tela Sobre — informacoes sobre o sistema e a startup TechVision.
 */
public class SobreFrame extends JFrame {

    public SobreFrame(JFrame pai) {
        construirUI(pai);
    }

    private void construirUI(JFrame pai) {
        setTitle("Miltinho Manager — Sobre");
        setSize(480, 360);
        setLocationRelativeTo(pai);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel root = UIEstilo.painel();
        root.setLayout(new BorderLayout(0, 16));
        root.setBorder(new EmptyBorder(24, 30, 24, 30));

        root.add(UIEstilo.titulo("Sobre o Miltinho Manager"), BorderLayout.NORTH);

        // ---- Card com informacoes ----
        JPanel card = new JPanel(new GridLayout(0, 2, 10, 12));
        card.setBackground(UIEstilo.BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIEstilo.LINE),
                new EmptyBorder(16, 18, 16, 18)));

        String[][] infos = {
            {"Startup",         "TechVision"},
            {"Slogan",          "Transformando pequenos negócios com tecnologia."},
            {"Comércio parceiro","Bar e Restaurante Miltinho"},
            {"Sistema",         "Miltinho Manager v1.0"},
            {"Disciplina",      "Challenge – 2º Bimestre"},
            {"Integrantes",     "Kauã Davi, Gustavo Gonsaga, Roger Miguel"},
            {"Tecnologias",     "Java 17 · Spring Boot · JPA · H2"},
        };

        for (String[] par : infos) {
            JLabel rotulo = UIEstilo.rotulo(par[0] + ":");
            rotulo.setFont(new Font("Arial", Font.BOLD, 12));
            rotulo.setForeground(UIEstilo.ACCENT);

            JLabel valor = new JLabel("<html>" + par[1] + "</html>");
            valor.setFont(UIEstilo.F_BODY);
            valor.setForeground(UIEstilo.TEXT);

            card.add(rotulo);
            card.add(valor);
        }

        // ---- Botao voltar ----
        JButton btnVoltar = UIEstilo.botaoSecundario("← Voltar");
        btnVoltar.setPreferredSize(new Dimension(110, 32));
        btnVoltar.addActionListener(e -> dispose());

        JPanel rodape = UIEstilo.painel();
        rodape.setLayout(new FlowLayout(FlowLayout.LEFT));
        rodape.add(btnVoltar);

        root.add(card, BorderLayout.CENTER);
        root.add(rodape, BorderLayout.SOUTH);
        setContentPane(root);
    }
}
