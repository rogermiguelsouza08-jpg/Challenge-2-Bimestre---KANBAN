package com.miltinho.manager.ui;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/**
 * Centraliza cores, fontes e fabrica de componentes estilizados
 * para manter consistencia visual entre todas as telas do Miltinho Manager.
 */
public final class UIEstilo {

    private UIEstilo() {}

    // ---- Paleta ----
    public static final Color NAVY      = new Color(0x1B, 0x2A, 0x4A);
    public static final Color ACCENT    = new Color(0xC9, 0x71, 0x2B);
    public static final Color BG        = new Color(0xFA, 0xF7, 0xF2);
    public static final Color BG_CARD   = Color.WHITE;
    public static final Color LINE      = new Color(0xD9, 0xD2, 0xC5);
    public static final Color TEXT      = new Color(0x26, 0x26, 0x26);
    public static final Color TEXT_MUTE = new Color(0x6B, 0x6B, 0x6B);
    public static final Color BTN_FILL  = new Color(0xF2, 0xC5, 0x72);
    public static final Color BTN_DANGER= new Color(0xE5, 0x53, 0x3C);

    // ---- Fontes ----
    public static final Font F_TITLE    = new Font("Arial", Font.BOLD,  20);
    public static final Font F_HEADING  = new Font("Arial", Font.BOLD,  15);
    public static final Font F_BODY     = new Font("Arial", Font.PLAIN, 13);
    public static final Font F_SMALL    = new Font("Arial", Font.PLAIN, 11);
    public static final Font F_BTN      = new Font("Arial", Font.BOLD,  13);

    // ---- Bordas ----
    public static Border bordaCampo() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(LINE, 1),
                BorderFactory.createEmptyBorder(4, 8, 4, 8));
    }

    public static Border bordaCard() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(LINE, 1),
                BorderFactory.createEmptyBorder(12, 14, 12, 14));
    }

    // ---- Fabrica de componentes ----

    public static JLabel rotulo(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(F_BODY);
        l.setForeground(TEXT_MUTE);
        return l;
    }

    public static JLabel titulo(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(F_TITLE);
        l.setForeground(NAVY);
        return l;
    }

    public static JTextField campo() {
        JTextField f = new JTextField();
        f.setFont(F_BODY);
        f.setForeground(TEXT);
        f.setBorder(bordaCampo());
        f.setBackground(BG_CARD);
        return f;
    }

    /** Botao primario (amarelo-caramelo). */
    public static JButton botaoPrimario(String texto) {
        JButton b = new JButton(texto) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? BTN_FILL.darker() :
                            getModel().isRollover() ? BTN_FILL.brighter() : BTN_FILL);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        estilizarBotao(b, TEXT);
        return b;
    }

    /** Botao secundario (fundo claro, borda suave). */
    public static JButton botaoSecundario(String texto) {
        JButton b = new JButton(texto);
        estilizarBotao(b, TEXT_MUTE);
        b.setBackground(new Color(0xE7, 0xE2, 0xD8));
        return b;
    }

    /** Botao de perigo (vermelho). */
    public static JButton botaoPerigo(String texto) {
        JButton b = new JButton(texto) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? BTN_DANGER.darker() : BTN_DANGER);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        estilizarBotao(b, Color.WHITE);
        return b;
    }

    private static void estilizarBotao(JButton b, Color fg) {
        b.setFont(F_BTN);
        b.setForeground(fg);
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    }

    /** Painel com fundo padrao da aplicacao. */
    public static JPanel painel() {
        JPanel p = new JPanel();
        p.setBackground(BG);
        return p;
    }

    /** Configura o Look-and-Feel para o padrao do sistema operacional. */
    public static void aplicarLaf() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Mantem o padrao Swing se falhar
        }
    }
}
