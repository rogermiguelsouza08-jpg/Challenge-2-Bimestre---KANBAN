package com.miltinho.manager;

import com.miltinho.manager.model.Produto;
import com.miltinho.manager.repository.PedidoRepository;
import com.miltinho.manager.repository.ProdutoRepository;
import com.miltinho.manager.service.ProdutoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testes de integracao para ProdutoService com H2 em memoria.
 */
@SpringBootTest
@Transactional
class MiltinhoAppTests {

    @Autowired
    private ProdutoService produtoService;

    @Autowired
    private ProdutoRepository produtoRepository;

    @Autowired
    private PedidoRepository pedidoRepository;

    @BeforeEach
    void setUp() {
        // Pedidos precisam ser removidos antes dos Produtos por causa da FK (produto_id)
        pedidoRepository.deleteAll();
        produtoRepository.deleteAll();
    }

    @Test
    @DisplayName("Deve salvar um produto e recupera-lo por ID")
    void testSalvarEBuscarProduto() {
        Produto p = new Produto("Marmitex Teste", 15.00, 30);
        Produto salvo = produtoService.salvar(p);

        assertNotNull(salvo.getId(), "ID nao pode ser nulo apos salvar");
        Optional<Produto> encontrado = produtoService.buscarPorId(salvo.getId());
        assertTrue(encontrado.isPresent(), "Produto deve ser encontrado pelo ID");
        assertEquals("Marmitex Teste", encontrado.get().getNome());
    }

    @Test
    @DisplayName("Deve listar todos os produtos cadastrados")
    void testListarTodos() {
        produtoService.salvar(new Produto("Cerveja", 8.50, 100));
        produtoService.salvar(new Produto("Refrigerante", 5.00, 60));

        List<Produto> lista = produtoService.listarTodos();
        assertEquals(2, lista.size());
    }

    @Test
    @DisplayName("Deve excluir produto por ID")
    void testExcluirProduto() {
        Produto p = produtoService.salvar(new Produto("Agua", 3.00, 200));
        Long id = p.getId();

        produtoService.excluir(id);

        Optional<Produto> resultado = produtoService.buscarPorId(id);
        assertFalse(resultado.isPresent(), "Produto excluido nao deve ser encontrado");
    }

    @Test
    @DisplayName("Deve rejeitar produto com nome vazio")
    void testValidacaoNomeVazio() {
        Produto invalido = new Produto("", 10.00, 5);
        assertThrows(IllegalArgumentException.class, () -> produtoService.salvar(invalido));
    }

    @Test
    @DisplayName("Deve rejeitar produto com preco negativo")
    void testValidacaoPrecoNegativo() {
        Produto invalido = new Produto("Produto X", -1.00, 5);
        assertThrows(IllegalArgumentException.class, () -> produtoService.salvar(invalido));
    }

    @Test
    @DisplayName("Deve identificar produtos com estoque baixo")
    void testEstoqueBaixo() {
        produtoService.salvar(new Produto("Produto OK",    10.00, 50));
        produtoService.salvar(new Produto("Produto Baixo", 10.00, 5));

        List<Produto> baixos = produtoService.produtosComEstoqueBaixo();
        assertEquals(1, baixos.size());
        assertEquals("Produto Baixo", baixos.get(0).getNome());
    }
}
